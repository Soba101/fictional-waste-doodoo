# Waste Detection Dashboard Package
# This file makes waste-d a proper Python package
